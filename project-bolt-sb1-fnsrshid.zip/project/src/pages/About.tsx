import { CheckCircle2 } from 'lucide-react';

export default function About() {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-80 md:h-96 overflow-hidden">
        <img
          src="https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1"
          alt="About Us"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">About Orbit Neosoft Solutions</h1>
            <p className="text-lg text-gray-100 max-w-2xl">
              Leading innovators in technology solutions and talent acquisition
            </p>
          </div>
        </div>
      </section>

      {/* Company Overview */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Our Story
              </h2>
              <p className="text-gray-700 mb-4 leading-relaxed">
                Founded in 2009, Orbit Neosoft Solutions emerged with a singular mission: to bridge the gap between innovative technology and business success. What started as a small consultancy has grown into a trusted partner for enterprises and startups alike.
              </p>
              <p className="text-gray-700 mb-4 leading-relaxed">
                Over the past 15 years, we've successfully delivered over 200 projects, ranging from custom software development to large-scale IT transformations. Our expertise spans across industries including finance, healthcare, e-commerce, and manufacturing.
              </p>
              <p className="text-gray-700 leading-relaxed">
                Today, Orbit Neosoft Solutions stands as a beacon of excellence, known for our unwavering commitment to quality, innovation, and client success.
              </p>
            </div>
            <div className="bg-gradient-to-br from-blue-100 to-slate-100 rounded-xl h-80 flex items-center justify-center">
              <div className="text-center">
                <div className="text-6xl font-bold text-blue-900 mb-2">15+</div>
                <p className="text-gray-700 text-lg">Years of Excellence</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Vision and Mission */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Vision</h3>
              <p className="text-gray-700 leading-relaxed">
                To be the most trusted technology partner for businesses worldwide, enabling them to achieve their full potential through innovative solutions and exceptional talent.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h3>
              <p className="text-gray-700 leading-relaxed">
                To deliver transformative technology solutions and top-tier talent that drive business growth, enhance operational efficiency, and create lasting value for our clients.
              </p>
            </div>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-sm">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Our Core Values</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { title: 'Excellence', desc: 'Delivering highest quality in all we do' },
                { title: 'Innovation', desc: 'Embracing new ideas and technologies' },
                { title: 'Integrity', desc: 'Building trust through honesty and transparency' },
                { title: 'Partnership', desc: 'Collaborating closely with our clients' },
              ].map((value, index) => (
                <div key={index}>
                  <h4 className="font-semibold text-gray-900 mb-2">{value.title}</h4>
                  <p className="text-gray-600 text-sm">{value.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Team Highlights */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-12 text-center">
            Why Our Team Excels
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: 'Deep Expertise',
                desc: 'Our team brings decades of combined experience across technology domains',
              },
              {
                title: 'Continuous Learning',
                desc: 'We stay ahead of industry trends and invest in ongoing professional development',
              },
              {
                title: 'Client-Focused',
                desc: 'Every project is approached with understanding of your unique business needs',
              },
              {
                title: 'Quality Assurance',
                desc: 'Rigorous testing and quality standards ensure exceptional results',
              },
              {
                title: 'Collaborative Approach',
                desc: 'We work as an extension of your team, not just vendors',
              },
              {
                title: 'On-Time Delivery',
                desc: 'Proven track record of delivering projects on schedule and within budget',
              },
            ].map((item, index) => (
              <div key={index} className="flex gap-4">
                <CheckCircle2 className="w-6 h-6 text-blue-600 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">{item.title}</h4>
                  <p className="text-gray-600">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-blue-900 text-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            {[
              { number: '200+', label: 'Projects Delivered' },
              { number: '98%', label: 'Client Satisfaction' },
              { number: '50+', label: 'Team Members' },
              { number: '15+', label: 'Years of Excellence' },
            ].map((stat, index) => (
              <div key={index}>
                <div className="text-4xl md:text-5xl font-bold mb-2">{stat.number}</div>
                <p className="text-blue-100">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

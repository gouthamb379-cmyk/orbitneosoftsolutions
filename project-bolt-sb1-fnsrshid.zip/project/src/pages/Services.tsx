import { ArrowRight, Code2, Shield, Users, Brain, BarChart3, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Services() {
  const services = [
    {
      icon: Code2,
      title: 'Software Development',
      description: 'Custom software solutions built from the ground up',
      features: [
        'Web application development',
        'Mobile app development',
        'API design and development',
        'Cloud-native solutions',
        'Legacy system modernization',
      ],
    },
    {
      icon: Shield,
      title: 'IT Services & Consulting',
      description: 'Comprehensive IT infrastructure and support',
      features: [
        'IT infrastructure design',
        'System administration',
        'Network security solutions',
        '24/7 technical support',
        'Cloud migration services',
      ],
    },
    {
      icon: Users,
      title: 'Staffing & Talent Solutions',
      description: 'Top talent for your technology projects',
      features: [
        'Software engineers',
        'Project managers',
        'QA specialists',
        'DevOps engineers',
        'Contract and permanent placements',
      ],
    },
    {
      icon: Brain,
      title: 'AI & Machine Learning Solutions',
      description: 'Cutting-edge AI integration for modern businesses',
      features: [
        'AI strategy consulting',
        'Machine learning models',
        'Data analytics solutions',
        'AI-powered automation',
        'Predictive analytics',
      ],
    },
    {
      icon: BarChart3,
      title: 'Business Intelligence',
      description: 'Data-driven insights for better decisions',
      features: [
        'Data warehousing',
        'Business analytics',
        'Dashboard development',
        'Reporting solutions',
        'Data visualization',
      ],
    },
    {
      icon: Lock,
      title: 'Cybersecurity',
      description: 'Protect your business from digital threats',
      features: [
        'Security assessments',
        'Penetration testing',
        'Security compliance',
        'Incident response',
        'Security training',
      ],
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-80 md:h-96 overflow-hidden">
        <img
          src="https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=1200&h=800&dpr=1"
          alt="Services"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
          <div className="text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Services</h1>
            <p className="text-lg text-gray-100 max-w-2xl">
              Comprehensive technology solutions tailored to your business needs
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const IconComponent = service.icon;
              return (
                <div
                  key={index}
                  className="border border-gray-200 rounded-xl p-8 hover:shadow-lg hover:border-blue-200 transition-all"
                >
                  <div className="bg-blue-100 w-14 h-14 rounded-lg flex items-center justify-center mb-4">
                    <IconComponent className="w-7 h-7 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 mb-6">
                    {service.description}
                  </p>
                  <ul className="space-y-3 mb-6">
                    {service.features.map((feature, fIndex) => (
                      <li key={fIndex} className="flex items-start gap-3">
                        <div className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2 flex-shrink-0" />
                        <span className="text-gray-700 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Service Process */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-12 text-center">
            Our Proven Approach
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[
              {
                step: '1',
                title: 'Consultation',
                desc: 'We listen to understand your unique challenges and goals',
              },
              {
                step: '2',
                title: 'Assessment',
                desc: 'Detailed analysis of your current systems and requirements',
              },
              {
                step: '3',
                title: 'Implementation',
                desc: 'Expert execution of tailored solutions with minimal disruption',
              },
              {
                step: '4',
                title: 'Support',
                desc: 'Ongoing support and optimization for continued success',
              },
            ].map((item, index) => (
              <div key={index}>
                <div className="bg-white rounded-xl p-8 text-center h-full border border-gray-200">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-600 text-white font-bold rounded-full mb-4 text-lg">
                    {item.step}
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">
                    {item.title}
                  </h3>
                  <p className="text-gray-600 text-sm">
                    {item.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technology Stack */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-12 text-center">
            Technology Stack
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                category: 'Frontend',
                technologies: ['React', 'Vue.js', 'Angular', 'Next.js', 'TypeScript'],
              },
              {
                category: 'Backend',
                technologies: ['Node.js', 'Python', 'Java', 'Go', '.NET'],
              },
              {
                category: 'Cloud & DevOps',
                technologies: ['AWS', 'Azure', 'GCP', 'Docker', 'Kubernetes'],
              },
              {
                category: 'Databases',
                technologies: ['PostgreSQL', 'MongoDB', 'Redis', 'Elasticsearch', 'MySQL'],
              },
              {
                category: 'AI/ML',
                technologies: ['TensorFlow', 'PyTorch', 'Scikit-learn', 'OpenAI API'],
              },
              {
                category: 'Tools & Platforms',
                technologies: ['Git', 'Jenkins', 'Terraform', 'ELK Stack', 'Grafana'],
              },
            ].map((stack, index) => (
              <div key={index} className="bg-gray-50 rounded-xl p-6 border border-gray-200">
                <h3 className="font-semibold text-gray-900 mb-4">{stack.category}</h3>
                <div className="flex flex-wrap gap-2">
                  {stack.technologies.map((tech, tIndex) => (
                    <span
                      key={tIndex}
                      className="inline-block bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-900 text-white py-16 md:py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-lg text-blue-100 mb-8">
            Let's discuss how we can help your business succeed
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center justify-center gap-2 bg-blue-500 hover:bg-blue-600 font-semibold py-3 px-8 rounded-lg transition-colors"
          >
            Schedule a Consultation <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
